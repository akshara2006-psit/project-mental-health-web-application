

// Face Expression Detection Code

const video = document.getElementById('video')
const faceCam = document.getElementById('faceCam')
const captureEmotion = document.getElementById('captureEmotion')
const userQuery = document.getElementById('userQuery')
const getResponse = document.getElementById('getResponse')
const mainChatArea = document.getElementById('mainChatArea')

const width = video.offsetWidth;
const height = 319;

// BEST FACE EXPRESSION GLOBAL VARIABLES

let bestExpression="";
let bestExpressionValue=100;
let bestDiff=100;

Promise.all([
  faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
  faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
  faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
  faceapi.nets.faceExpressionNet.loadFromUri('/models')
]).then(startVideo)

function startVideo() {
  navigator.getUserMedia(
    { video: {} },
    stream => video.srcObject = stream,
    err => console.error(err)
  )
}

video.addEventListener('play', () => {
  const canvas = faceapi.createCanvasFromMedia(video)
  faceCam.append(canvas)
  const displaySize = { width: width, height: height }
  
  faceapi.matchDimensions(canvas, displaySize)
  setInterval(async () => {
    const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceExpressions()
    // console.log(detections);
    
    const resizedDetections = faceapi.resizeResults(detections, displaySize)
    canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height)
    faceapi.draw.drawDetections(canvas, resizedDetections)
    faceapi.draw.drawFaceLandmarks(canvas, resizedDetections)
    faceapi.draw.drawFaceExpressions(canvas, resizedDetections)
  }, 100)
})
// Capturing the face Expression Below on button click
captureEmotion.addEventListener('click',() => {
  // Resetting previous best Expression
  bestDiff = 100;
  // Capture current video frame as a canvas
  const clickedCanvas = document.createElement('Canvas');
  clickedCanvas.width = video.videoWidth;
  clickedCanvas.height = video.videoHeight;
  const ctx = clickedCanvas.getContext('2d');
  ctx.drawImage(video, 0, 0, clickedCanvas.width, clickedCanvas.height);

  // Convert clickedCanvas to base64-encoded data URL
  const dataURL = clickedCanvas.toDataURL();

  // Update image source
  const imgElement = document.getElementById('capturedImage');
  imgElement.src = dataURL;

  const input = imgElement;
  const detectionsWithExpressions = faceapi.detectSingleFace(input, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceExpressions().then(detectionsWithExpressions => {
    // Getting the best Face Expression Below

    for(key in detectionsWithExpressions['expressions']) {
      if(detectionsWithExpressions['expressions'].hasOwnProperty(key)) {
          var value = detectionsWithExpressions['expressions'][key];

          if(value > 1){
            let diff = value-1;
            if(diff<bestDiff){
              bestExpressionValue = value;
              bestDiff = diff;
              bestExpression = key;
            }

          }else{
            let diff = 1-value;

            if(diff<bestDiff){
              bestExpressionValue = value;
              bestDiff = diff;
              bestExpression = key;
            }
          }
      }
    }
    // Write switch and case conditions to give ai suggestions based on the face expression of the user

    
    const personExpression = {
      "neutral": "I'm feeling unbiased today, suggest me things to change my Frame of mind",
      "happy": "I'm feeling delighted today, suggest me something to enjoy my happiness",
      "sad": "feeling sad and need some relaxation techniques",
      "angry": "I'm feeling angry today, how can I control myself doings unexpected things",
      "fearful": "I'm feeling afraid ,how can I quickly get rid of it",
      "disgusted": "I'm feeling disgusted. Can you give me a short list of uplifting activities or resources to help improve my mood",
      "surprised": "I'm surprised , how can I accede this unexpected situation calmly"
    };

    let prompt = "";

    switch (bestExpression) {
      case "neutral":
        // code to execute if expression matches value1
        prompt = personExpression[bestExpression];

        break;
      case "happy":
        // code to execute if expression matches value1
        prompt = personExpression[bestExpression];
        break;
      case "sad":
        // code to execute if expression matches value1
        prompt = personExpression[bestExpression];
        break;
      case "angry":
        // code to execute if expression matches value1
        prompt = personExpression[bestExpression];
        break;
      case "fearful":
        // code to execute if expression matches value1
        prompt = personExpression[bestExpression];
        break;
      case "disgusted":
        // code to execute if expression matches value1
        prompt = personExpression[bestExpression];
        break;
      case "surprised":
        // code to execute if expression matches value1
        prompt = personExpression[bestExpression];
        break;
      default:
        // code to execute if no case matches
        prompt = "If you don't know about the mental condition of a person what would you recommend";
        break;
    }

    sendUserEmotionState(bestExpression)

    const AIURL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=AIzaSyCmFDAW8GfdjQqXjXls_Q_s1yTGgid8hfc';

    console.log(prompt+aiConfigFaceExpression);
    
    
    fetch(AIURL, {
      method: "POST",
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt+aiConfigFaceExpression}] }],
      }),
    }).then((response)=>response.json()).then((data)=>{
      
      let responseData = data.candidates[0].content.parts[0].text;
      responseData = responseData.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
    responseData = responseData.replace(/\*(.*?)\*/g, '<i>$1</i>');
      responseData = responseData.replaceAll("*", "•");
      responseData = responseData.replaceAll("##", "");
  

      // Getting current date and time for using it in hashing

      const date = new Date();
      const year = date.getFullYear();
      const month = date.getMonth() + 1;
      const day = date.getDate();
      const hours = date.getHours();
      const minutes = date.getMinutes();
      const seconds = date.getSeconds();

      const responseInstance = `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;

      // import md5 from 'js-md5';

      // md5('Message to hash');
      // var hash = md5.create();
      // hash.update('Message to hash');
      // hash.hex();
                                          
      let content = `<div class="jokes-stories-ai">
                  <pre style="width:100%; text-align: left; margin:0; white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap white-space: -o-pre-wrap; word-wrap: break-word;"><p  id="content-${md5(responseInstance)}">`+responseData+`</p></pre>
                  <span class="align-end readIt" id="${md5(responseInstance)}" onclick="readResponse('${md5(responseInstance)}')">🔈</span>
              </div>`;
      mainChatArea.insertAdjacentHTML('beforeend', content);

      const div = document.getElementById('mainChatArea');
      div.scrollTop = div.scrollHeight;

    })

  })
});


// Voice to text Converter Codes

function voiceToText(){
  var recognition = new webkitSpeechRecognition();
  // $("#recordAudio").attr("class","fa-solid fa-ear-listen");
  $("#recordAudio").attr("class","fa-regular fa-circle-stop");
  recognition.maxAlternatives = 100;
  // recognition.continuous = true;
  recognition.lang="en-GB";
  recognition.onresult= function(event){
      console.log(event);
      document.getElementById("userQuery").value = event.results[0][0].transcript;
      $("#recordAudio").attr("class","fa-solid fa-microphone");
  }
  recognition.start();
}


// Text to Voice Converter Code

function readResponse(e){
  let responseToRead = "content-"+e;

  let voiceIco = document.getElementById(e)
  let speech  = document.getElementById(responseToRead)
  count = 1;

  if(!speechSynthesis.speaking || speechSynthesis.pause()){
      speechText = speech.innerHTML;
      speechText = speechText.replaceAll("<b>", "");
      speechText = speechText.replaceAll("</b>", "");
      speechText = speechText.replaceAll("•", "");
      var speechVoice = new SpeechSynthesisUtterance();
      var voices = speechSynthesis.getVoices();
      speechVoice.voice = voices[2];
      speechVoice.text = speechText;
      speechVoice.lang = 'en-US';
      speechVoice.pitch = 0.8; // Set the pitch to 1.2 (medium-high)
      speechVoice.rate = 1; // Set the rate to 0.8 (slightly slower)
      speechSynthesis.speak(speechVoice);  
  }

  if(count == 1){
    voiceIco.innerHTML="🔊";
    speechSynthesis.resume()
    setTimeout(() => {
      count = 2;
    }, 300);
    
  }else{
    speechSynthesis.paused
    voiceIco.innerHTML="🔈";
    count = 1;

  }

  setInterval(() => {
    if(!speechSynthesis.speaking && count == 2){
      voiceIco.innerHTML="🔈";
      count = 1;
    }
  },100);


  }



// AI CHATBOT API CONNECTION BELOW
userQuery.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    // Code to execute when Enter key is pressed
    sendUserQuery();
    getResponseFromAI();
    clearInput();
  }
});
getResponse.addEventListener("click",()=>{
  sendUserQuery();
  
  getResponseFromAI();
  clearInput();
});

function clearInput(){
  userQuery.value = '';
}

function sendUserQuery(){
  let userQueryContent = `<div class="align-end chat-property-same chat-of-user">
                <p>`+userQuery.value+`</p>
            </div>`;
  mainChatArea.insertAdjacentHTML('beforeend', userQueryContent);
  const div = document.getElementById('mainChatArea');
  div.scrollTop = div.scrollHeight;
}

function sendUserEmotionState(e){
  let userQueryContent = `<div class="align-end chat-property-same chat-of-user">
                <p>Your Current Emotion: `+e+`</p>
            </div>`;
  mainChatArea.insertAdjacentHTML('beforeend', userQueryContent);
  const div = document.getElementById('mainChatArea');
  div.scrollTop = div.scrollHeight;
}

function getResponseFromAI(){
  const AIURL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=AIzaSyCmFDAW8GfdjQqXjXls_Q_s1yTGgid8hfc';
  console.log(userQuery.value+aiConfig);
  
  fetch(AIURL, {
    method: "POST",
    body: JSON.stringify({
      contents: [{ parts: [{ text: userQuery.value+aiConfig}] }],
    }),
  }).then((response)=>response.json()).then((data)=>{
    
    let responseData = data.candidates[0].content.parts[0].text;
    

    responseData = responseData.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
    responseData = responseData.replace(/\*(.*?)\*/g, '<i>$1</i>');
    responseData = responseData.replaceAll("*", "•");
    responseData = responseData.replaceAll("##", "");

    // Getting current date and time for using it in hashing

    const date = new Date();
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();

    const responseInstance = `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;

    // import md5 from 'js-md5';

    // md5('Message to hash');
    // var hash = md5.create();
    // hash.update('Message to hash');
    // hash.hex();
                                        
    let content = `<div class="jokes-stories-ai">
                <pre style="width:100%; text-align: left; margin:0; white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap white-space: -o-pre-wrap; word-wrap: break-word;"><p  id="content-${md5(responseInstance)}">`+responseData+`</p></pre>
                <span class="align-end readIt" id="${md5(responseInstance)}" onclick="readResponse('${md5(responseInstance)}')">🔈</span>
            </div>`;
    mainChatArea.insertAdjacentHTML('beforeend', content);
    const div = document.getElementById('mainChatArea');
    div.scrollTop = div.scrollHeight;
    
  });
}

let content = `<div class="jokes-stories-ai">
                <pre style="width:100%; text-align: left; margin:0; white-space: pre-wrap; white-space: -moz-pre-wrap; white-space: -pre-wrap white-space: -o-pre-wrap; word-wrap: break-word;"><p>How can I help you today?</p></pre>
            </div>`;
    mainChatArea.insertAdjacentHTML('beforeend', content);