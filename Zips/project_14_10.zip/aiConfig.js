// Edit this data for ai configuration
const aiName = "Ram";
const mainWork = "act as a ai chatbot which helps improving mental health";
const faceEmotionSuggestionConfig = "Amit Tiwari";
// (Dark Humor, Self-deprecating humor, Observational humor, Wordplay and cleverness, Inclusive and respectful humor)
const jokeConfig = "New hindi or English jokes";
const storyConfig = "Stories (motivational, funny)";
const suggestionConfig = "Suggestions (to get in happy,focused and active mind state)";
const finalMoodState = "Happy, Focused and active Mind State";
const yogaConfig = "yoga (to increase my focus, mindfulness)";
const meditationConfig = "Meditations (to achieve stress relief, focus, self-awareness)";


// Don't edit Below Data

const aiConfigFaceExpression = ` suggest me some ${suggestionConfig}, ${jokeConfig}, ${meditationConfig}, ${storyConfig} or ${yogaConfig}. Suggest only Important Things.`;

const aiConfig = ` (${mainWork}. Your Name is ${aiName})`;
